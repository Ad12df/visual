﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Dominio;

namespace QUANTICSTORE_0._00001
{
    public partial class LOGIN : Form
    {
        public LOGIN()
        {
            InitializeComponent();
        }

        [DllImport("user32.dll", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.dll", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int Msg, int wParam, int lParam);


        private void TXT_USER_Enter(object sender, EventArgs e)
        {
            if (TXT_USER.Text == "USUARIO")
            {
                TXT_USER.Text = "";
                TXT_USER.ForeColor = Color.LightGray;
            }
        }

        private void TXT_USER_Leave(object sender, EventArgs e)
        {
            if (TXT_USER.Text == "")
            {
                TXT_USER.Text = "USUARIO";
                TXT_USER.ForeColor = Color.DimGray;
            }
        }

        private void TXT_PASS_Enter(object sender, EventArgs e)
        {
            if (TXT_PASS.Text == "CONTRASEÑA")
            {
                TXT_PASS.Text = "";
                TXT_PASS.ForeColor = Color.LightGray;
                TXT_PASS.UseSystemPasswordChar = true;
            }
        }

        private void TXT_PASS_Leave(object sender, EventArgs e)
        {
            if (TXT_PASS.Text == "")
            {
                TXT_PASS.Text = "CONTRASEÑA";
                TXT_PASS.ForeColor = Color.DimGray;
                TXT_PASS.UseSystemPasswordChar= false;
            }
        }

        private void BOX_CLOSE_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BOX_MINI_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void LOGIN_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void BTN_LOGIN_Click(object sender, EventArgs e)
        {
            if (TXT_USER.Text != "USUARIO")
            {
                if (TXT_PASS.Text != "CONTRASEÑA")
                {
                    UserModel user = new UserModel();
                    var validLogin = user.LoginUser(TXT_USER.Text, TXT_PASS.Text);
                    if (validLogin == true)
                    {
                        Inicio main= new Inicio();
                        main.Show();
                        main.FormClosed += Logout;
                        this.Hide();
                    }
                    else
                    {
                        msgError("USUARIO O CONTRASEÑA INCORRECTO");
                        TXT_PASS.Text = "CONTRASEÑA"; 
                        TXT_USER.Focus();
                    }
                }
                else msgError("porfavor coloque su CONTRASEÑA");
            }
            else msgError("porfavor coloque el usuario");
        }
        private void msgError(string msg)
        {
            l_error_mensaje.Text = "" + msg;
            l_error_mensaje.Visible = true;
        }
        private void Logout(object sender, FormClosedEventArgs e)
        {
            TXT_PASS.Text = "CONTRASEÑA"; // Fixed the error by removing the invalid parentheses  
            TXT_PASS.UseSystemPasswordChar = false;
            TXT_USER.Text = "USUARIO";
            l_error_mensaje.Visible = false;
            this.Show();
            //TXT_USER.Focus();
        }

        private void LOGIN_Load(object sender, EventArgs e)
        {

        }
    }
}
