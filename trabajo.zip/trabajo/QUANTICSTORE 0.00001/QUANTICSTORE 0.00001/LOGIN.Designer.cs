﻿namespace QUANTICSTORE_0._00001
{
    partial class LOGIN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LOGIN));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.TXT_USER = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.TXT_PASS = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.BTN_LOGIN = new System.Windows.Forms.Button();
            this.LINK_PASS = new System.Windows.Forms.LinkLabel();
            this.BOX_CLOSE = new FontAwesome.Sharp.IconPictureBox();
            this.BOX_MINI = new FontAwesome.Sharp.IconPictureBox();
            this.l_error_mensaje = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BOX_CLOSE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BOX_MINI)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(250, 330);
            this.panel1.TabIndex = 0;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(65, 105);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(117, 117);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // TXT_USER
            // 
            this.TXT_USER.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
            this.TXT_USER.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TXT_USER.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXT_USER.ForeColor = System.Drawing.Color.DimGray;
            this.TXT_USER.Location = new System.Drawing.Point(306, 77);
            this.TXT_USER.Name = "TXT_USER";
            this.TXT_USER.Size = new System.Drawing.Size(426, 25);
            this.TXT_USER.TabIndex = 1;
            this.TXT_USER.Text = "USUARIO";
            this.TXT_USER.Enter += new System.EventHandler(this.TXT_USER_Enter);
            this.TXT_USER.Leave += new System.EventHandler(this.TXT_USER_Leave);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(306, 105);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(426, 5);
            this.panel2.TabIndex = 3;
            // 
            // TXT_PASS
            // 
            this.TXT_PASS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
            this.TXT_PASS.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TXT_PASS.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXT_PASS.ForeColor = System.Drawing.Color.DimGray;
            this.TXT_PASS.Location = new System.Drawing.Point(306, 145);
            this.TXT_PASS.Name = "TXT_PASS";
            this.TXT_PASS.Size = new System.Drawing.Size(426, 25);
            this.TXT_PASS.TabIndex = 2;
            this.TXT_PASS.Text = "CONTRASEÑA";
            this.TXT_PASS.Enter += new System.EventHandler(this.TXT_PASS_Enter);
            this.TXT_PASS.Leave += new System.EventHandler(this.TXT_PASS_Leave);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(306, 173);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(426, 5);
            this.panel3.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(464, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 34);
            this.label1.TabIndex = 5;
            this.label1.Text = "LOGIN";
            // 
            // BTN_LOGIN
            // 
            this.BTN_LOGIN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.BTN_LOGIN.FlatAppearance.BorderSize = 0;
            this.BTN_LOGIN.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.BTN_LOGIN.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BTN_LOGIN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_LOGIN.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_LOGIN.ForeColor = System.Drawing.Color.LightGray;
            this.BTN_LOGIN.Location = new System.Drawing.Point(306, 238);
            this.BTN_LOGIN.Name = "BTN_LOGIN";
            this.BTN_LOGIN.Size = new System.Drawing.Size(426, 40);
            this.BTN_LOGIN.TabIndex = 3;
            this.BTN_LOGIN.Text = "Acceder";
            this.BTN_LOGIN.UseVisualStyleBackColor = false;
            this.BTN_LOGIN.Click += new System.EventHandler(this.BTN_LOGIN_Click);
            // 
            // LINK_PASS
            // 
            this.LINK_PASS.ActiveLinkColor = System.Drawing.Color.Blue;
            this.LINK_PASS.AutoSize = true;
            this.LINK_PASS.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LINK_PASS.LinkColor = System.Drawing.Color.DimGray;
            this.LINK_PASS.Location = new System.Drawing.Point(421, 295);
            this.LINK_PASS.Name = "LINK_PASS";
            this.LINK_PASS.Size = new System.Drawing.Size(195, 17);
            this.LINK_PASS.TabIndex = 0;
            this.LINK_PASS.TabStop = true;
            this.LINK_PASS.Text = "¿Has perdido la contraseña?";
            // 
            // BOX_CLOSE
            // 
            this.BOX_CLOSE.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
            this.BOX_CLOSE.ForeColor = System.Drawing.Color.DarkGray;
            this.BOX_CLOSE.IconChar = FontAwesome.Sharp.IconChar.X;
            this.BOX_CLOSE.IconColor = System.Drawing.Color.DarkGray;
            this.BOX_CLOSE.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.BOX_CLOSE.IconSize = 16;
            this.BOX_CLOSE.Location = new System.Drawing.Point(751, 12);
            this.BOX_CLOSE.Name = "BOX_CLOSE";
            this.BOX_CLOSE.Size = new System.Drawing.Size(17, 16);
            this.BOX_CLOSE.TabIndex = 8;
            this.BOX_CLOSE.TabStop = false;
            this.BOX_CLOSE.Click += new System.EventHandler(this.BOX_CLOSE_Click);
            // 
            // BOX_MINI
            // 
            this.BOX_MINI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
            this.BOX_MINI.ForeColor = System.Drawing.Color.DarkGray;
            this.BOX_MINI.IconChar = FontAwesome.Sharp.IconChar.Minus;
            this.BOX_MINI.IconColor = System.Drawing.Color.DarkGray;
            this.BOX_MINI.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.BOX_MINI.IconSize = 16;
            this.BOX_MINI.Location = new System.Drawing.Point(728, 12);
            this.BOX_MINI.Name = "BOX_MINI";
            this.BOX_MINI.Size = new System.Drawing.Size(17, 16);
            this.BOX_MINI.TabIndex = 9;
            this.BOX_MINI.TabStop = false;
            this.BOX_MINI.Click += new System.EventHandler(this.BOX_MINI_Click);
            // 
            // l_error_mensaje
            // 
            this.l_error_mensaje.AutoSize = true;
            this.l_error_mensaje.Font = new System.Drawing.Font("MS Reference Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l_error_mensaje.ForeColor = System.Drawing.Color.DarkGray;
            this.l_error_mensaje.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.l_error_mensaje.Location = new System.Drawing.Point(303, 194);
            this.l_error_mensaje.Name = "l_error_mensaje";
            this.l_error_mensaje.Size = new System.Drawing.Size(56, 23);
            this.l_error_mensaje.TabIndex = 10;
            this.l_error_mensaje.Text = "Error";
            this.l_error_mensaje.Visible = false;
            // 
            // LOGIN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
            this.ClientSize = new System.Drawing.Size(780, 330);
            this.Controls.Add(this.l_error_mensaje);
            this.Controls.Add(this.BOX_MINI);
            this.Controls.Add(this.BOX_CLOSE);
            this.Controls.Add(this.LINK_PASS);
            this.Controls.Add(this.BTN_LOGIN);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.TXT_PASS);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.TXT_USER);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "LOGIN";
            this.Opacity = 0.9D;
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LOGIN";
            this.Load += new System.EventHandler(this.LOGIN_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.LOGIN_MouseDown);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BOX_CLOSE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BOX_MINI)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox TXT_USER;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox TXT_PASS;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BTN_LOGIN;
        private System.Windows.Forms.LinkLabel LINK_PASS;
        private FontAwesome.Sharp.IconPictureBox BOX_CLOSE;
        private System.Windows.Forms.PictureBox pictureBox1;
        private FontAwesome.Sharp.IconPictureBox BOX_MINI;
        private System.Windows.Forms.Label l_error_mensaje;
    }
}