create database TiendaRopa
go
use TiendaRopa
go

create table Productos (
Id_Producto int primary key identity,
NombreProducto nvarchar(100),
Descripcion nvarchar(300),
Precio money,
Imagen varbinary(max)
)
go

insert into Productos values (
'ASUS Vivobook 15',
'Laptop delgada con pantalla Full HD, ideal para trabajo y estudio',
529.99,
(select * from openrowset(BULK 'C:\Users\javie\OneDrive\Desktop\Imagenes que necesitare\61gKkYQn6lL._AC_SX466_.jpg', SINGLE_BLOB) as Imagen)
);

insert into Productos values (
'Acer Nitro 5',
'Laptop gamer con procesador potente y gr�ficos dedicados',
899.99,
(select * from openrowset(BULK 'C:\Users\javie\OneDrive\Desktop\Imagenes que necesitare\71F-Wcriq4L._AC_SX466_.jpg', SINGLE_BLOB) as Imagen)
);

insert into Productos values (
'ASUS ROG Strix',
'Laptop para gaming de alto rendimiento con dise�o agresivo',
1249.99,
(select * from openrowset(BULK 'C:\Users\javie\OneDrive\Desktop\Imagenes que necesitare\71zuMSjwDfL._AC_SX466_.jpg', SINGLE_BLOB) as Imagen)
);

insert into Productos values (
'Lenovo IdeaPad 3',
'Port�til eficiente con buena autonom�a y pantalla c�moda',
459.99,
(select * from openrowset(BULK 'C:\Users\javie\OneDrive\Desktop\Imagenes que necesitare\514x0Kw6C2L._AC_SX466_.jpg', SINGLE_BLOB) as Imagen)
);

insert into Productos values (
'HP Pavilion 14',
'Listo para cualquier lugar: con su dise�o delgado y ligero',
177.15,
(select * from openrowset(BULK 'C:\Users\javie\OneDrive\Desktop\Imagenes que necesitare\815uX7wkOZS._AC_SX466_.jpg', SINGLE_BLOB) as Imagen)
);





insert into Productos values ('HP Computadora port�til 14','Listo para cualquier lugar: con su dise�o delgado y ligero',177.15,
(select * from openrowset (BULK 'C:\Users\javie\OneDrive\Desktop\Imagenes que necesitare\815uX7wkOZS._AC_SX466_.jpg', SINGLE_BLOB) AS Image))

insert into Productos values ('HP Computadora port�til 14','Listo para cualquier lugar: con su dise�o delgado y ligero',177.15,
(select * from openrowset (BULK 'C:\Users\javie\OneDrive\Desktop\Imagenes que necesitare\815uX7wkOZS._AC_SX466_.jpg', SINGLE_BLOB) AS Image))

insert into Productos values ('HP Computadora port�til 14','Listo para cualquier lugar: con su dise�o delgado y ligero',177.15,
(select * from openrowset (BULK 'C:\Users\javie\OneDrive\Desktop\Imagenes que necesitare\815uX7wkOZS._AC_SX466_.jpg', SINGLE_BLOB) AS Image))

insert into Productos values ('HP Computadora port�til 14','Listo para cualquier lugar: con su dise�o delgado y ligero',177.15,
(select * from openrowset (BULK 'C:\Users\javie\OneDrive\Desktop\Imagenes que necesitare\815uX7wkOZS._AC_SX466_.jpg', SINGLE_BLOB) AS Image))

insert into Productos values ('HP Computadora port�til 14','Listo para cualquier lugar: con su dise�o delgado y ligero',177.15,
(select * from openrowset (BULK 'C:\Users\javie\OneDrive\Desktop\Imagenes que necesitare\815uX7wkOZS._AC_SX466_.jpg', SINGLE_BLOB) AS Image))

select * from Productos

create table Users(
    UserID int identity(1,1) primary key,
    LoginName nvarchar (100) unique not null,
    Password nvarchar (100) not null,
    FirstName nvarchar(100) not null,
    LastName nvarchar(100) not null,
    Position nvarchar (100) not null,
    Email nvarchar(150)not null
)

insert into Users values ('admin','admin','Jackson','Collins','Administrator','Support@SystemAll.biz')
insert into Users values ('Ben','abc123456','Benjamin','Thompson','Manager','BenThompson@MyCompany.com')
insert into Users values ('Kathy','abc123456','Kathrine','Smith','CFO','KathySmith@MyCompany.com')

select * from Users


